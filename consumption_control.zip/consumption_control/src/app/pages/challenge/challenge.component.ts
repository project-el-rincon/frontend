import { Component } from '@angular/core';

@Component({
  selector: 'app-challenge',
  imports: [],
  templateUrl: './challenge.component.html',
  styleUrl: './challenge.component.css'
})
export class ChallengeComponent {

}
