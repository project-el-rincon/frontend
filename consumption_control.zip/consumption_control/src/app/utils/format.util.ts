export function formatNumber(value: number): string {
    return value.toFixed(2);
  }
  