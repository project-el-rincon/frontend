export interface SensorData {
    id: number;
    type: string;
    value: number;
    timestamp: Date;
    roomId: number;
  }
  